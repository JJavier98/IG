#include "piernas_toro.h"
#include "node.h"

_piernas_toro::_piernas_toro()
{
	
   	calcularNormales();
}
