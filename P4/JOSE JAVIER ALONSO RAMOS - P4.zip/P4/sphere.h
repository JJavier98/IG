#ifndef SPHERE_H
#define SPHERE_H

#include "node.h"

class _sphere:public _node
{
public:
   _sphere(float Size=1.0);
};

#endif
