#ifndef BASE_H
#define BASE_H

#include "cylinder.h"
#include "tronco_grua.h"
#include "node.h"

class _base:public _node
{
protected:

public:
	_base();
};

#endif
