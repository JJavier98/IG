#ifndef EXTENSOR_H
#define EXTENSOR_H

#include "paralelepipedo.h"
#include "node.h"
#include "punta.h"

class _extensor:public _node
{
private:

public:
	_extensor();
};

#endif
