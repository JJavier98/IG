#ifndef BRAZO_1_H
#define BRAZO_1_H

#include "node.h"
#include "extensor.h"

class _brazo:public _node
{
private:
public:
  	_brazo();
};

#endif
