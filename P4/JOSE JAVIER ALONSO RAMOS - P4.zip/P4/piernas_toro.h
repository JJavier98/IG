#ifndef PIERNAS_TORO_H
#define PIERNAS_TORO_H

#include "cylinder.h"
#include <cmath>
#include "node.h"


class _piernas_toro:public _node
{
public:
	_piernas_toro();

};

#endif
