#ifndef CONE_H
#define CONE_H

#include "node.h"

class _cone:public _node
{
public:
   _cone(float Size=1.0);
};

#endif
