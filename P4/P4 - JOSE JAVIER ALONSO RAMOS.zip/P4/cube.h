/*
 * Practicas de IG
 * José Javier Alonso Ramos
 * jotajota98@correo.ugr.es
 *
 */

#ifndef CUBE_H
#define CUBE_H

#include "node.h"

class _cube:public _node
{
public:
   _cube(float Size=1.0);
};

#endif