/*
 * Practicas de IG
 * Domingo Martin Perandres© 2014-2018
 * dmartin@ugr.es
 *
 * GPL 3
 */

#ifndef TETRAHEDRON_H
#define TETRAHEDRON_H

#include "node.h"

class _tetrahedron:public _node
{
public:
   _tetrahedron(float Size=1.0);
};

#endif
