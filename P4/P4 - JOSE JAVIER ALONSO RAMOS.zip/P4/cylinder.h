#ifndef CYLINDER_H
#define CYLINDER_H

#include "node.h"

class _cylinder:public _node
{
public:
   _cylinder(float R=0.5, float H=1.0);
};

#endif
