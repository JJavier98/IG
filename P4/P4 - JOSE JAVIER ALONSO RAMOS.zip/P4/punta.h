#ifndef PUNTA_H
#define PUNTA_H

#include "node.h"

class _punta:public _node
{
private:
public:
	_punta();

};

#endif
