#ifndef CUENCO_H
#define CUENCO_H

#include "node.h"

class _cuenco:public _node
{
private:

public:
   _cuenco(float R=1, float H=0.7);
};

#endif
