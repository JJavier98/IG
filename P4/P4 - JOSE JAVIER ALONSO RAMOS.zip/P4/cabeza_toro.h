#ifndef CABEZA_TORO_H
#define CABEZA_TORO_H

#include "cone.h"
#include "paralelepipedo.h"
#include <cmath>
#include "node.h"


class _cabeza_toro:public _node
{
public:
	_cabeza_toro(float W = 1.5, float H=0.5);

};

#endif
