#ifndef TRONCO_H
#define TRONCO_H

#include "paralelepipedo.h"
#include "brazo.h"
#include "node.h"

class _tronco:public _node
{
protected:
public:
	_tronco();

};

#endif
