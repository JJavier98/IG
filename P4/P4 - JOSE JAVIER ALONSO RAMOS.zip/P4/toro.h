#ifndef TORO_H
#define TORO_H

#include "cuerpo_toro.h"
#include "piernas_toro.h"
#include "cabeza_toro.h"
#include <cmath>
#include "node.h"

class _toro:public _node
{
public:
	_toro();
};

#endif
