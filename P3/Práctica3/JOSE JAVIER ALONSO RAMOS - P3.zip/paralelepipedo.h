/*
 * Practicas de IG
 * José Javier Alonso Ramos
 * jotajota98@correo.ugr.es
 *
 */

#ifndef PARALEL_H
#define PARALEL_H

#include "object3d.h"

class _paralel:public _object3D
{
public:
   _paralel(float W=0.5, float H=1.0);
};

#endif